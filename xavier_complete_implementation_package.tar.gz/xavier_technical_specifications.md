# XAVIER ECOSYSTEM - TECHNICAL SPECIFICATIONS
# Complete Architecture for Top 5 Market-Viable Apps

## SYSTEM ARCHITECTURE OVERVIEW

### **Tech Stack (Unified Across All Apps)**
```
FRONTEND:
- React 18+ (component library)
- Tailwind CSS (ADHD-optimized: bold colors, clear hierarchy)
- Framer Motion (smooth animations, dopamine-triggering)
- React Query (data fetching/caching)
- Zustand (lightweight state management)

BACKEND:
- Node.js + Express (API server)
- PostgreSQL (relational data: tasks, contacts, compliance logs)
- Redis (caching, session management, real-time features)
- Bull (job queues for Comet automation scripts)

INTEGRATIONS:
- Comet Browser SDK (agentic automation)
- OpenAI GPT-4 API (AI expansion, summarization)
- Last.fm API (music data for Neuro Sync)
- Google APIs (Calendar, Gmail, Drive)
- Notion API (database backend option)
- Airtable API (no-code database option)

INFRASTRUCTURE:
- Vercel (frontend hosting, serverless functions)
- Railway / Render (backend hosting)
- Supabase (PostgreSQL + Auth + Storage)
- Cloudflare (CDN, DDoS protection)

MONITORING:
- Sentry (error tracking)
- PostHog (product analytics)
- LogRocket (session replay for debugging)
```

---

## APP 1: XAVIER CRM - TECHNICAL SPECS

### **API Endpoints**

```typescript
// CONTACTS
POST   /api/contacts/sync              // Sync from LinkedIn/Gmail
GET    /api/contacts                   // List all contacts
GET    /api/contacts/:id               // Get single contact
PUT    /api/contacts/:id               // Update contact
DELETE /api/contacts/:id               // Archive contact
POST   /api/contacts/:id/tag           // Add energy/relationship tag
GET    /api/contacts/search?q=         // Search by name/company

// INTERACTIONS
POST   /api/interactions               // Log new interaction
GET    /api/interactions/:contactId    // Get interaction history
PUT    /api/interactions/:id           // Update interaction notes

// REMINDERS
GET    /api/reminders/due              // Get reminders due today
POST   /api/reminders                  // Create reminder
PUT    /api/reminders/:id/complete     // Mark complete
DELETE /api/reminders/:id/snooze       // Snooze for 7 days

// NETWORK MAP
GET    /api/network-graph              // Get D3.js visualization data
GET    /api/network-health             // Calculate network health score

// AUTOMATION
POST   /api/automation/briefing/:meetingId  // Generate pre-meeting brief
POST   /api/automation/context-restore      // Restore last interaction context
```

### **Database Schema (PostgreSQL)**

```sql
-- CONTACTS TABLE
CREATE TABLE contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(50),
  company VARCHAR(255),
  title VARCHAR(255),
  linkedin_url TEXT,
  profile_photo_url TEXT,
  relationship_strength VARCHAR(20) CHECK (relationship_strength IN ('strong', 'medium', 'weak')),
  energy_level VARCHAR(20) CHECK (energy_level IN ('energizing', 'neutral', 'draining')),
  last_contact_date TIMESTAMP,
  tags TEXT[], -- Array of tags: ['client', 'mentor', 'friend']
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, email)
);

-- INTERACTIONS TABLE
CREATE TABLE interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id UUID NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  interaction_date TIMESTAMP NOT NULL,
  interaction_type VARCHAR(50) CHECK (interaction_type IN ('email', 'meeting', 'phone', 'text', 'linkedin')),
  sentiment VARCHAR(20) CHECK (sentiment IN ('positive', 'neutral', 'negative')),
  topics TEXT[], -- Array of topics discussed
  notes TEXT,
  energy_cost INTEGER CHECK (energy_cost BETWEEN 1 AND 5),
  created_at TIMESTAMP DEFAULT NOW()
);

-- REMINDERS TABLE
CREATE TABLE reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id UUID NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  due_date TIMESTAMP NOT NULL,
  reason VARCHAR(255), -- "60 days no contact", "birthday", etc.
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'snoozed')),
  suggested_action TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES for performance
CREATE INDEX idx_contacts_user_id ON contacts(user_id);
CREATE INDEX idx_contacts_last_contact ON contacts(last_contact_date);
CREATE INDEX idx_interactions_contact_date ON interactions(contact_id, interaction_date DESC);
CREATE INDEX idx_reminders_due_date ON reminders(due_date) WHERE status = 'pending';
```

### **UI Wireframes (Component Structure)**

```
┌─────────────────────────────────────────────────────┐
│ XAVIER CRM - Dashboard                              │
├─────────────────────────────────────────────────────┤
│ [Search contacts...] [+ Add Contact] [Network Map] │
├─────────────────────────────────────────────────────┤
│                                                     │
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│ │   🔴 RED     │ │   🟡 YELLOW  │ │   🟢 GREEN   ││
│ │   5 contacts │ │   12 contacts│ │   23 contacts││
│ │Need attention│ │ Check in soon│ │  All good    ││
│ └──────────────┘ └──────────────┘ └──────────────┘│
│                                                     │
│ TODAY'S RELATIONSHIP TASKS (3)                      │
│ ┌─────────────────────────────────────────────────┐│
│ │ 🎂 Sarah's birthday - Send card                  ││
│ │ ⏰ 62 days since last contact with John          ││
│ │ 💼 Mike mentioned Q4 planning - Follow up        ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ RECENT INTERACTIONS                                 │
│ ┌─────────────────────────────────────────────────┐│
│ │ Jane Doe - Meeting - 2 hours ago                 ││
│ │ "Discussed Q4 strategy, follow up on pricing"   ││
│ │ [View Context] [Schedule Next]                   ││
│ └─────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────┘

NETWORK MAP VIEW (D3.js Force-Directed Graph):
- Nodes = contacts (size = interaction frequency)
- Colors = energy levels (green/yellow/red)
- Lines = shared connections/projects
- Interactive: Click → context panel, Drag → reorganize
```

---

## APP 2: MEDICARE SALES AUTOMATION - TECHNICAL SPECS

### **API Endpoints**

```typescript
// LEADS
POST   /api/leads/import-facebook       // Import from FB Ads
POST   /api/leads                       // Create lead manually
GET    /api/leads                       // List leads (with filters)
GET    /api/leads/:id                   // Get single lead
PUT    /api/leads/:id/score             // Recalculate lead score
PUT    /api/leads/:id/status            // Update pipeline status

// SOA (Scope of Appointment)
POST   /api/soa/generate/:leadId        // Generate SOA form
POST   /api/soa/send-docusign           // Send for e-signature
GET    /api/soa/:leadId/status          // Check signature status

// PLAN COMPARISON
POST   /api/plans/compare               // Generate comparison table
GET    /api/plans/available?zip=33180   // Get plans by ZIP

// ENROLLMENT
POST   /api/enrollments                 // Submit enrollment
GET    /api/enrollments/:id/status      // Check submission status
PUT    /api/enrollments/:id/confirm     // Confirm enrollment approved

// COMMISSIONS
GET    /api/commissions/dashboard       // Get commission metrics
GET    /api/commissions/pending         // Calculate pending commissions
POST   /api/commissions/reconcile       // Match enrollments to payments

// COMPLIANCE
POST   /api/compliance/log-interaction  // Log client interaction
GET    /api/compliance/audit/:clientId  // Generate audit report
GET    /api/compliance/alerts           // Get compliance warnings
```

### **Database Schema (PostgreSQL)**

```sql
-- LEADS TABLE
CREATE TABLE leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID NOT NULL REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  age INTEGER,
  zip_code VARCHAR(10),
  phone VARCHAR(50),
  email VARCHAR(255),
  lead_source VARCHAR(50) CHECK (lead_source IN ('facebook', 'linkedin', 'referral', 'website')),
  lead_score INTEGER CHECK (lead_score BETWEEN 0 AND 100),
  status VARCHAR(50) DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'appointed', 'soa_complete', 'enrolled', 'dead')),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- PLANS TABLE (Reference data)
CREATE TABLE plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  carrier VARCHAR(100), -- "UnitedHealthcare", "Humana", etc.
  plan_name VARCHAR(255),
  plan_type VARCHAR(50) CHECK (plan_type IN ('medicare_advantage', 'supplement', 'part_d')),
  monthly_premium DECIMAL(10,2),
  star_rating DECIMAL(2,1),
  commission_amount DECIMAL(10,2),
  service_area_zips TEXT[], -- Array of ZIP codes
  created_at TIMESTAMP DEFAULT NOW()
);

-- ENROLLMENTS TABLE
CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id),
  plan_id UUID NOT NULL REFERENCES plans(id),
  enrollment_date TIMESTAMP NOT NULL,
  confirmation_number VARCHAR(100),
  commission_status VARCHAR(50) DEFAULT 'pending' CHECK (commission_status IN ('pending', 'paid', 'chargeback')),
  commission_amount DECIMAL(10,2),
  payment_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- COMPLIANCE_LOG TABLE
CREATE TABLE compliance_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id),
  agent_id UUID NOT NULL REFERENCES users(id),
  interaction_date TIMESTAMP NOT NULL,
  interaction_type VARCHAR(50) CHECK (interaction_type IN ('call', 'email', 'meeting')),
  soa_signed BOOLEAN DEFAULT FALSE,
  disclosures_provided TEXT[], -- Array: ['independent_agent', 'star_rating', 'commission_structure']
  recording_url TEXT, -- If call was recorded
  created_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_leads_agent_status ON leads(agent_id, status);
CREATE INDEX idx_leads_score ON leads(lead_score DESC);
CREATE INDEX idx_enrollments_commission_status ON enrollments(commission_status);
CREATE INDEX idx_compliance_lead_date ON compliance_log(lead_id, interaction_date DESC);
```

### **UI Wireframes**

```
┌─────────────────────────────────────────────────────┐
│ MEDICARE SALES AUTOMATION - Pipeline                │
├─────────────────────────────────────────────────────┤
│ [New Leads (23)] [SOA Sent (12)] [Enrolled (8)]     │
├─────────────────────────────────────────────────────┤
│                                                     │
│ ⚡ NEW TIER A LEAD!                                 │
│ ┌─────────────────────────────────────────────────┐│
│ │ John Smith, 64                                   ││
│ │ 📍 Miami, FL 33180                               ││
│ │ 📞 (305) 555-1234                                ││
│ │ 🎯 Lead Score: 92 (URGENT - turning 65 in 45 days)││
│ │                                                   ││
│ │ [Call Now] [Send SOA] [View Profile]            ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ COMMISSION DASHBOARD                                │
│ ┌────────────┬────────────┬────────────┐          │
│ │ Pending    │ Paid YTD   │ Forecast   │          │
│ │ $8,900     │ $47,200    │ $156k      │          │
│ └────────────┴────────────┴────────────┘          │
│                                                     │
│ [Progress bar: 68% to annual goal]                 │
└─────────────────────────────────────────────────────┘
```

---

## APP 3: NEURO SYNC DASHBOARD - TECHNICAL SPECS

### **API Endpoints**

```typescript
// MUSIC DATA
POST   /api/lastfm/sync                // Pull full Last.fm history
GET    /api/lastfm/current             // Get currently playing track
GET    /api/lastfm/analysis            // Get productivity correlation

// FOCUS TRACKING
POST   /api/focus/score                // Calculate current Neuro Sync Score
GET    /api/focus/timeline             // Get focus score timeline (today)
GET    /api/focus/insights             // Get AI-generated insights

// PLAYLISTS
GET    /api/playlists/recommended      // Get task-specific playlist
POST   /api/playlists/generate         // Generate new playlist
GET    /api/playlists/:id/effectiveness // Get productivity boost %

// BIOMETRICS
POST   /api/biometrics/sync            // Sync Apple Watch data
GET    /api/biometrics/energy          // Get current energy score

// PREDICTIONS
GET    /api/predictions/peak-hours     // Predict optimal work windows
POST   /api/predictions/schedule-optimize // Auto-block calendar
```

### **Database Schema (PostgreSQL)**

```sql
-- LISTENING_HISTORY TABLE
CREATE TABLE listening_history (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  timestamp TIMESTAMP NOT NULL,
  track_name VARCHAR(500),
  artist_name VARCHAR(500),
  album_name VARCHAR(500),
  genre VARCHAR(100),
  bpm INTEGER,
  valence DECIMAL(3,2), -- Happiness score 0-1
  energy DECIMAL(3,2), -- Intensity score 0-1
  work_session_id UUID REFERENCES work_sessions(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- WORK_SESSIONS TABLE
CREATE TABLE work_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  task_type VARCHAR(100) CHECK (task_type IN ('coding', 'writing', 'email', 'meeting', 'design', 'admin')),
  neuro_sync_score_avg INTEGER CHECK (neuro_sync_score_avg BETWEEN 0 AND 100),
  outcome VARCHAR(50) CHECK (outcome IN ('completed', 'incomplete', 'interrupted')),
  flow_minutes INTEGER, -- Time spent in 80+ score
  interruptions_count INTEGER DEFAULT 0,
  playlist_id UUID REFERENCES playlists(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- BIOMETRIC_DATA TABLE
CREATE TABLE biometric_data (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  timestamp TIMESTAMP NOT NULL,
  heart_rate INTEGER,
  hrv INTEGER, -- Heart rate variability
  movement_minutes INTEGER,
  sleep_hours DECIMAL(3,1), -- Previous night
  caffeine_mg INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

-- PLAYLISTS TABLE
CREATE TABLE playlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  name VARCHAR(255) NOT NULL, -- "Deep Focus", "Creative Sprint"
  task_type_optimized_for VARCHAR(100),
  avg_productivity_boost DECIMAL(5,2), -- % improvement vs baseline
  tracks JSONB, -- Array of Last.fm track IDs
  created_at TIMESTAMP DEFAULT NOW()
);

-- FOCUS_SCORES TABLE (high-frequency data)
CREATE TABLE focus_scores (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  timestamp TIMESTAMP NOT NULL,
  neuro_sync_score INTEGER CHECK (neuro_sync_score BETWEEN 0 AND 100),
  app_switches_per_min DECIMAL(3,1),
  keystroke_velocity INTEGER, -- WPM
  music_playing BOOLEAN,
  created_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_listening_history_user_timestamp ON listening_history(user_id, timestamp DESC);
CREATE INDEX idx_work_sessions_user_start ON work_sessions(user_id, start_time DESC);
CREATE INDEX idx_biometric_data_user_timestamp ON biometric_data(user_id, timestamp DESC);
CREATE INDEX idx_focus_scores_user_timestamp ON focus_scores(user_id, timestamp DESC);
```

### **UI Wireframes**

```
┌─────────────────────────────────────────────────────┐
│ NEURO SYNC DASHBOARD                                │
├─────────────────────────────────────────────────────┤
│ 🟢 FLOW STATE (Score: 88/100)                       │
│ [Keep going! You're in the zone.]                   │
├─────────────────────────────────────────────────────┤
│                                                     │
│ FOCUS TIMELINE (Today)                              │
│ ┌───────────────────────────────────────────┐      │
│ │100 │     ╱╲  ╱╲                            │      │
│ │ 75 │   ╱╲│  ╲│  ╲╱╲                       │      │
│ │ 50 │  ╱  │   │      ╲                     │      │
│ │ 25 │╱    │   │        ╲                   │      │
│ │  0 └────────────────────────────────────  │      │
│ │    9am  10  11  12pm  1   2   3   4   5   │      │
│ └───────────────────────────────────────────┘      │
│                                                     │
│ NOW PLAYING: Elliott Smith - "Between the Bars"    │
│ ┌─────────────────────────────────────────────────┐│
│ │ This song boosts your focus by 32% historically  ││
│ │ [Continue playlist] [Switch to Creative Sprint] ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ OPTIMAL WORK WINDOWS THIS WEEK                      │
│ ┌─────────────────────────────────────────────────┐│
│ │ 🔥 Tue 9-11am: Peak focus (predicted score: 92)  ││
│ │ 🟢 Thu 9-10am: High energy (predicted score: 84) ││
│ │ 🟡 Wed 2-3pm: Moderate (predicted score: 68)     ││
│ │ 🔴 Fri 3-4pm: Energy crash (predicted score: 42) ││
│ └─────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────┘
```

---

## APP 4: WORKFLOW NAVIGATOR - TECHNICAL SPECS

### **API Endpoints**

```typescript
// TASK AGGREGATION
POST   /api/tasks/sync                 // Pull from all sources
GET    /api/tasks                      // List all tasks
POST   /api/tasks                      // Create task manually
PUT    /api/tasks/:id                  // Update task
DELETE /api/tasks/:id                  // Delete task

// PRIORITIZATION
POST   /api/tasks/score                // Calculate urgency/importance scores
GET    /api/tasks/matrix               // Get Eisenhower matrix data
GET    /api/tasks/recommendation       // Get "What should I do now?" answer

// ENERGY MATCHING
POST   /api/tasks/match-energy         // Match tasks to current energy
GET    /api/tasks/chunked/:id          // Get task broken into chunks

// CONTEXT
POST   /api/tasks/:id/start            // Log task start (capture context)
POST   /api/tasks/:id/pause            // Log interruption
POST   /api/tasks/:id/resume           // Restore context on resume

// INSIGHTS
GET    /api/insights/productivity      // Get productivity metrics
GET    /api/insights/time-wasted       // Context-switching cost analysis
```

### **Database Schema (PostgreSQL)**

```sql
-- TASKS TABLE
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  title VARCHAR(500) NOT NULL,
  description TEXT,
  source VARCHAR(50) CHECK (source IN ('todoist', 'notion', 'gmail', 'slack', 'github', 'manual')),
  source_id VARCHAR(255), -- External ID from source system
  due_date TIMESTAMP,
  estimated_time_min INTEGER,
  cognitive_load INTEGER CHECK (cognitive_load BETWEEN 1 AND 5),
  urgency_score INTEGER CHECK (urgency_score BETWEEN 0 AND 100),
  importance_score INTEGER CHECK (importance_score BETWEEN 0 AND 100),
  quadrant VARCHAR(50) CHECK (quadrant IN ('do_first', 'schedule', 'delegate', 'delete')),
  status VARCHAR(50) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'blocked', 'complete')),
  last_worked_on TIMESTAMP,
  interruption_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- TASK_CHUNKS TABLE (for overwhelm management)
CREATE TABLE task_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  chunk_order INTEGER NOT NULL,
  title VARCHAR(500) NOT NULL,
  estimated_time_min INTEGER,
  cognitive_load INTEGER CHECK (cognitive_load BETWEEN 1 AND 5),
  status VARCHAR(50) DEFAULT 'not_started' CHECK (status IN ('not_started', 'complete')),
  created_at TIMESTAMP DEFAULT NOW()
);

-- TASK_CONTEXT TABLE (for context restoration)
CREATE TABLE task_context (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL,
  event_type VARCHAR(50) CHECK (event_type IN ('start', 'pause', 'resume', 'complete')),
  context_snapshot JSONB, -- Last sentence typed, last line of code, open tabs, etc.
  created_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_tasks_user_status ON tasks(user_id, status);
CREATE INDEX idx_tasks_urgency ON tasks(urgency_score DESC) WHERE status != 'complete';
CREATE INDEX idx_tasks_due_date ON tasks(due_date) WHERE status != 'complete';
CREATE INDEX idx_task_context_task_timestamp ON task_context(task_id, timestamp DESC);
```

### **UI Wireframes**

```
┌─────────────────────────────────────────────────────┐
│ WORKFLOW NAVIGATOR                                  │
├─────────────────────────────────────────────────────┤
│ [🎯 What should I do now?]      Energy: 🟢 85/100   │
├─────────────────────────────────────────────────────┤
│                                                     │
│ RIGHT NOW, DO THIS:                                 │
│ ┌─────────────────────────────────────────────────┐│
│ │ ✏️  Send Q4 proposal to Sarah                    ││
│ │                                                   ││
│ │ ⏱️  30 minutes                                    ││
│ │ 🧠 Medium cognitive load                          ││
│ │ 🔥 Due in 4 hours (URGENT)                       ││
│ │                                                   ││
│ │ WHY NOW?                                          ││
│ │ • You have 45-min window before next meeting     ││
│ │ • Your energy (85%) matches task difficulty       ││
│ │ • High urgency + high importance                 ││
│ │                                                   ││
│ │ [Start Task] [Skip to Next]                      ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ AFTER THAT:                                         │
│ Review GitHub PR #247 (15 min, quick win)          │
│                                                     │
│ EISENHOWER MATRIX (47 tasks)                        │
│ ┌───────────────┬───────────────┐                  │
│ │ DO FIRST (5)  │ SCHEDULE (12) │                  │
│ │ 🔴🔴🔴🔴🔴      │ 🟢🟢🟢        │                  │
│ ├───────────────┼───────────────┤                  │
│ │ DELEGATE (8)  │ DELETE (22)   │                  │
│ │ 🟡🟡🟡         │ ⚫⚫⚫         │                  │
│ └───────────────┴───────────────┘                  │
└─────────────────────────────────────────────────────┘
```

---

## APP 5: MONEY MOVES EBOOK STUDIO - TECHNICAL SPECS

### **API Endpoints**

```typescript
// EBOOKS
POST   /api/ebooks                     // Create new ebook
GET    /api/ebooks                     // List user's ebooks
GET    /api/ebooks/:id                 // Get ebook details
PUT    /api/ebooks/:id                 // Update ebook
DELETE /api/ebooks/:id                 // Delete ebook

// CHAPTERS
POST   /api/chapters                   // Create chapter from template
GET    /api/chapters/:ebookId          // List chapters in ebook
PUT    /api/chapters/:id               // Update chapter content
POST   /api/chapters/:id/ai-expand     // AI content expansion

// CALCULATORS
POST   /api/calculators/embed          // Generate calculator embed code
POST   /api/calculators/calculate      // Run calculation (for testing)

// EXPORT
POST   /api/export/pdf/:ebookId        // Export to PDF
POST   /api/export/epub/:ebookId       // Export to ePub
POST   /api/export/mobi/:ebookId       // Export to Mobi
POST   /api/export/all/:ebookId        // Export all formats

// PUBLISHING
POST   /api/publish/gumroad            // Auto-publish to Gumroad
POST   /api/publish/social             // Generate social content

// COMPLIANCE
POST   /api/compliance/disclaimer      // Generate appropriate disclaimer
GET    /api/compliance/updates         // Check for regulatory updates
```

### **Database Schema (Notion or PostgreSQL)**

```sql
-- EBOOKS TABLE
CREATE TABLE ebooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  title VARCHAR(500) NOT NULL,
  target_audience VARCHAR(100) CHECK (target_audience IN ('retirees', 'young_professionals', 'business_owners', 'general')),
  status VARCHAR(50) DEFAULT 'brainstorm' CHECK (status IN ('brainstorm', 'writing', 'review', 'published')),
  chapter_count INTEGER DEFAULT 0,
  word_count_total INTEGER DEFAULT 0,
  publish_date TIMESTAMP,
  gumroad_url TEXT,
  revenue_ytd DECIMAL(10,2) DEFAULT 0,
  cover_image_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- CHAPTERS TABLE
CREATE TABLE chapters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ebook_id UUID NOT NULL REFERENCES ebooks(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL,
  title VARCHAR(500) NOT NULL,
  template_used VARCHAR(100) CHECK (template_used IN ('retirement', 'medicare', 'tax', 'investment', 'insurance')),
  content TEXT,
  word_count INTEGER DEFAULT 0,
  status VARCHAR(50) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'complete')),
  last_edited TIMESTAMP,
  compliance_review BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(ebook_id, chapter_number)
);

-- CONTENT_BANK TABLE (repurposed social content)
CREATE TABLE content_bank (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_chapter_id UUID REFERENCES chapters(id) ON DELETE SET NULL,
  content_type VARCHAR(50) CHECK (content_type IN ('tweet', 'linkedin', 'instagram', 'youtube', 'tiktok', 'email')),
  content_text TEXT NOT NULL,
  publish_date TIMESTAMP,
  engagement_metrics JSONB, -- {likes, shares, comments, etc.}
  created_at TIMESTAMP DEFAULT NOW()
);

-- CALCULATORS TABLE
CREATE TABLE calculators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  calculator_type VARCHAR(100) CHECK (calculator_type IN ('social_security_breakeven', 'medicare_plan_comparison', 'roth_conversion', 'retirement_savings')),
  config JSONB, -- Calculator-specific configuration
  embed_code TEXT,
  usage_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_ebooks_user_status ON ebooks(user_id, status);
CREATE INDEX idx_chapters_ebook_number ON chapters(ebook_id, chapter_number);
CREATE INDEX idx_content_bank_source ON content_bank(source_chapter_id);
```

### **UI Wireframes**

```
┌─────────────────────────────────────────────────────┐
│ MONEY MOVES EBOOK STUDIO                            │
├─────────────────────────────────────────────────────┤
│ [+ New Ebook] [Templates] [Calculators] [Publish]   │
├─────────────────────────────────────────────────────┤
│                                                     │
│ YOUR EBOOKS                                         │
│ ┌─────────────────────────────────────────────────┐│
│ │ 📘 Medicare Decoded                              ││
│ │ Status: Writing (68% complete)                   ││
│ │ 15 chapters • 23,400 words                       ││
│ │                                                   ││
│ │ ⚠️  3 chapters need compliance review            ││
│ │                                                   ││
│ │ [Continue Writing] [Export Preview]             ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ WRITING DASHBOARD                                   │
│ ┌──────────────┬──────────────┬──────────────┐     │
│ │ BACKLOG      │ IN PROGRESS  │ COMPLETE     │     │
│ │              │              │              │     │
│ │ 🔲 Ch 8      │ ✏️  Ch 3      │ ✅ Ch 1      │     │
│ │ 🔲 Ch 12     │ ✏️  Ch 5      │ ✅ Ch 2      │     │
│ │ 🔲 Ch 15     │ ✏️  Ch 9      │ ✅ Ch 4      │     │
│ │              │              │ ✅ Ch 6      │     │
│ │              │              │ ✅ Ch 7      │     │
│ └──────────────┴──────────────┴──────────────┘     │
│                                                     │
│ QUICK ACTIONS                                       │
│ [AI: Expand this outline]                          │
│ [Generate social posts from Ch 3]                  │
│ [Add disclaimers to all chapters]                  │
└─────────────────────────────────────────────────────┘
```

---

## UNIFIED AUTHENTICATION & USER MANAGEMENT

```sql
-- USERS TABLE (shared across all apps)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  profile_photo_url TEXT,
  subscription_tier VARCHAR(50) DEFAULT 'free' CHECK (subscription_tier IN ('free', 'pro', 'ultimate', 'enterprise')),
  stripe_customer_id VARCHAR(255),
  stripe_subscription_id VARCHAR(255),
  timezone VARCHAR(100) DEFAULT 'America/New_York',
  onboarding_completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- APP_PREFERENCES TABLE
CREATE TABLE app_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  app_name VARCHAR(100) NOT NULL CHECK (app_name IN ('xavier_crm', 'medicare_sales', 'neuro_sync', 'workflow_navigator', 'money_moves')),
  preferences JSONB, -- App-specific settings
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, app_name)
);
```

---

## COMET BROWSER SDK INTEGRATION

```typescript
// EXAMPLE: Comet SDK Usage in React Component

import { CometSDK } from '@comet-browser/sdk';

const comet = new CometSDK({
  apiKey: process.env.COMET_API_KEY
});

// Example 1: Scrape LinkedIn contacts
async function syncLinkedInContacts() {
  const contacts = await comet.executeScript({
    name: 'linkedin_contact_scraper',
    url: 'https://www.linkedin.com/mynetwork/invite-connect/connections/',
    instructions: `
      Extract all connections: name, company, title, profile URL.
      Return as JSON array.
    `,
    waitForSelector: '.mn-connection-card',
    parseResponse: 'json'
  });
  
  // Save to database
  await fetch('/api/contacts/sync', {
    method: 'POST',
    body: JSON.stringify({ contacts })
  });
}

// Example 2: Generate meeting briefing
async function generateMeetingBrief(meetingId: string) {
  const brief = await comet.query({
    prompt: `
      Pull data from CRM for all attendees in meeting ${meetingId}.
      Generate 1-page briefing with: last interaction, pending action items,
      personal details mentioned, suggested talking points.
    `,
    sources: ['xavier_crm_database', 'gmail', 'calendar']
  });
  
  return brief;
}

// Example 3: Auto-fill enrollment form
async function submitEnrollment(leadId: string) {
  const lead = await fetch(`/api/leads/${leadId}`).then(r => r.json());
  
  await comet.fillForm({
    url: 'https://carrier-portal.com/enrollment',
    credentials: {
      username: process.env.CARRIER_USERNAME,
      password: process.env.CARRIER_PASSWORD
    },
    fields: {
      beneficiaryName: lead.name,
      dateOfBirth: lead.dob,
      medicareNumber: lead.medicare_number,
      // ... etc
    },
    submit: true
  });
}
```

---

## PERFORMANCE OPTIMIZATION

### **Caching Strategy (Redis)**
```
- User sessions: 24 hours
- API responses: 5 minutes (for lists)
- Heavy computations (focus predictions): 1 hour
- Static data (plan lists, templates): 24 hours
```

### **Database Query Optimization**
```sql
-- Use materialized views for expensive queries
CREATE MATERIALIZED VIEW mv_user_productivity_metrics AS
SELECT 
  user_id,
  DATE(timestamp) as date,
  AVG(neuro_sync_score) as avg_focus,
  SUM(CASE WHEN neuro_sync_score > 80 THEN 1 ELSE 0 END) as flow_minutes
FROM focus_scores
GROUP BY user_id, DATE(timestamp);

-- Refresh daily at 2am
CREATE OR REPLACE FUNCTION refresh_productivity_metrics()
RETURNS void AS $$
BEGIN
  REFRESH MATERIALIZED VIEW mv_user_productivity_metrics;
END;
$$ LANGUAGE plpgsql;
```

### **Rate Limiting**
```typescript
// Prevent API abuse
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests, please try again later.'
});

app.use('/api/', limiter);
```

---

## SECURITY CONSIDERATIONS

### **Data Encryption**
- All passwords: bcrypt (cost factor 12)
- API keys: AES-256 encryption at rest
- TLS 1.3 for all connections
- PII fields (SSN, Medicare #): encrypted columns in DB

### **HIPAA Compliance** (for Medicare app)
- BAA with cloud providers
- Audit logging of all PHI access
- Data retention policy (10 years for Medicare)
- Breach notification procedures

### **OAuth Scopes** (minimal access principle)
- Gmail: `readonly` (not full access)
- Calendar: `events.readonly` (not `calendar.modify`)
- LinkedIn: `r_basicprofile r_network` (not `w_share`)

---

This technical specification provides the **complete blueprint** for building all 5 Xavier apps. Next, I'll create the ADHD-optimized workflows and musical integration features documents.

Ready for those?
